// import Loadable from '@loadable/component'
// export default Loadable(() => import('./Drawer'))

export { default } from './Drawer'
