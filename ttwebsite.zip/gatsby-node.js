const path = require("path")
const { paginate } = require(`gatsby-awesome-pagination`);

exports.createPages = async ({ graphql, actions }) => {
    const { createPage } = actions
  
    const { data } = await graphql(`
    query {    
        Blogs: allContentfulBlogPost {
            edges {
                node {
                    id
                    title
                }
            }
        }
    }
  `)
  const DEFAULT_BLOG_BASE_PATH = '/blog';
  const DEFAULT_BLOG_POSTS_PER_PAGE = 6;

  const basePath = DEFAULT_BLOG_BASE_PATH;
  const blogs = data.Blogs.edges;

  const templatesDir = path.resolve(__dirname, './src/templates');
  const postsPerPage = DEFAULT_BLOG_POSTS_PER_PAGE;

  paginate({
    createPage,
    items: blogs,
    itemsPerPage: postsPerPage,
    pathPrefix: basePath,
    component: path.resolve(templatesDir, 'BlogListTemplate.js'),
    context: {
      basePath,
      paginationPath: basePath
    },
  });
}